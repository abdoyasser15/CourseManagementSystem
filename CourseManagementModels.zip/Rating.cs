
namespace CourseManagementSystem.Models
{
    public class Rating
    {
        public int Id { get; set; }
        public int CourseId { get; set; }
        public Course Course { get; set; }

        public string StudentId { get; set; }
        public ApplicationUser Student { get; set; }

        public int Stars { get; set; }
        public string Comment { get; set; }
        public DateTime Date { get; set; }
    }
}
