
namespace CourseManagementSystem.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public DateTime StartDate { get; set; }

        public string InstructorId { get; set; }
        public ApplicationUser Instructor { get; set; }

        public int CategoryId { get; set; }
        public Category Category { get; set; }

        public ICollection<Enrollment> Enrollments { get; set; }
    }
}
